AJPOWER WORKFORCE — PRACTICAL TRAINING PACK
19 lessons · 18:41 total · English voice and on-screen instructions
Audio: AI-generated English narration is included in every MP4.
Code version: 3fcf2f5 (approved payroll polish merged to main).

START HERE
These are the WITH-AUDIO editions. Every MP4 has an English AAC narration track.
Use the player sound control and your device volume to hear it.

Extract the ZIP. Open index.html in Chrome, Edge or another modern browser.
Use the category filters or search, then Watch or Download a lesson.
You can also open the numbered MP4s directly in any standard video player.
The site lessons are portrait 1080×1920; desktop lessons are 1920×1080.
Use fullscreen and original quality to read smaller app controls.

GOOGLE DRIVE
Upload the MP4 files from videos/ to your chosen Drive folder.
Keep their numbered filenames so the lessons stay in order.
Drive can preview the MP4s. It does not run index.html as an interactive website.
Optional English SRT files are in captions/. Instructions are already visible in the video.
Embedded chapter support varies by player. The printable guide is AJPower-step-by-step-guide.pdf (also available as guide.html).

TRAINING DATA
All records, camera outcomes, amounts and saves are simulated, using the actual
AJPower interface. No real employee data or face images are included.
No action in these tutorials changed production payroll, paid money or deleted records.
Timing is paced for instruction and is not a production performance benchmark.
Example amounts and statutory settings are not legal or filing advice.
Check current company-approved rules, employee eligibility and permissions in the live app.
These lessons cover the main workflows below, rather than every possible configuration.

LEARNING ORDER
Site staff: 01–03.
HR setup: 04–10 and 15.
Monthly payroll: 13, 14, 17, 18; use 10–12 and 16 when those records need attention.

LESSONS
01. Site attendance & face registration (1:08)
02. Paper attendance & site registers (1:01)
03. Site transfers & attendance registers (1:01)
04. Offers & joining (1:02)
05. Enter an employee salary (0:53)
06. PF, ESI & tax declarations (1:01)
07. Build a salary structure (0:53)
08. Pay groups & policy selection (0:53)
09. Set attendance grace (0:53)
10. Review attendance & paper sheets (1:01)
11. Loans, advances & recoveries (1:01)
12. Final settlement adjustments (0:46)
13. Run monthly payroll, step by step (1:31)
14. Payroll & statutory reports (1:08)
15. Publish statutory settings (0:54)
16. Record and approve leave (0:46)
17. Hold and release salary (1:01)
18. One-time earnings & deductions (0:53)
19. Delete records with name confirmation (0:53)
